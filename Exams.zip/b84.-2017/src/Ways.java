public class Ways {
    public static int ways(int k ,int n){
        return ways(k,n,0,0);
    }

    private static int ways(int k,int n,int right,int cnt){

        if(right == n && k == 0)
            return cnt+1;
        if(k < 0)
            return 0;

        return (ways(k-1,n,right-1,cnt)+ways(k-1,n,right+1,cnt));

    }

    public static void main(String[]args){
        System.out.println(ways(4,2));
    }
}

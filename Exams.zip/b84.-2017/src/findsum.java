public class findsum {

    public static boolean findSum(int[]a,int sum){
        int s = findS(a);
        int i = a.length-1;
        
        if (s != 0) {
            i = Math.abs(s - 2 + a.length - 1);
        }
        while(s < i){
            if(a[s] + a[i] == sum)
                return true;
            else if(a[s]+a[i] < sum)
                s++;
            else
                i--;
        }

        return false;
    }

    private static int findS(int[]a){
        int i = 0;
        int j = 1;

        for(i = 0 ; i < a.length-1 ; i++){
            if(a[i] < a[j])
                j++;
            else
                return j;
        }

        return 0;
    }

    public static void main(String[]args){
        System.out.println(findSum(new int[]{65,70,-5,3,48,49,52},45));
    }
}

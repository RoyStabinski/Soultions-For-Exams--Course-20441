import java.util.Arrays;

public class minprice {

    public static int minPrice(int[][]mat){

        return minPrice(mat,0,0,0);

    }

    private static int minPrice(int[][]mat,int i ,int j,int sum){

        if(j == mat[0].length-1 && sum > 0)
            return sum + mat[i][j];

        if(mat[i][j] < 0 || j > mat[0].length-2 || i > mat.length-1 )
            return Integer.MAX_VALUE;

        int temp = mat[i][j];
        mat[i][j] = -1;
        int op1 = minPrice(mat,i,j+1,sum);
        int op2 = minPrice(mat,j,j,sum + temp);
        mat[i][j] = temp;

        return Math.min(op1,op2);
    }

    public static void main(String[]args){

        System.out.println(minPrice(new int[][]{{0,15,80,90},{-1,0,40,50},{-1,-1,0,70},{-1,-1,-1,0}}));

    }
}

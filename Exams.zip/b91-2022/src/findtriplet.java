public class findtriplet {

    public static int findTriplet(int[] arr) {

        int max1 = 0;
        int max2 = 0;
        int max3 = 0;
        int min1 = 0;
        int min2 = 0;
        int j = -1;
        int j2 = -1;
        int j3 = -1;


        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > max1) {
                max1 = Math.max(max1, arr[i]);
                j = i;
            }
        }

        for (int i = 0; i < arr.length && j != i; i++) {
            if (arr[i] > max2) {
                max2 = Math.max(max2, arr[i]);
                j2 = i;

            }
        }

        for (int i = 0; i < arr.length && i != j2; i++) {
            if (arr[i] > max3) {
                max3 = Math.max(max3, arr[i]);
            }
        }

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] < min1) {
                min1 = Math.min(min1, arr[i]);
                j3 = i;

            }
        }

        for (int i = 0; i < arr.length && i != j3; i++) {
            if (arr[i] < min2) {
                min2 = Math.min(min2, arr[i]);
            }
        }

        if (min1 * min2 * max1 > max1 * max2 * max3) {
            System.out.println(min1 + "\t" + min2 + "\t" + max1);
            return min1 * min2 * max1;
        } else {
            System.out.println(max1 + "\t" + max2 + "\t" + max3);
            return max1 * max2 * max3;
        }


    }

    public static void main(String[]args){
        System.out.println(findTriplet(new int[]{-4,1,-8,9,6}));
    }
}

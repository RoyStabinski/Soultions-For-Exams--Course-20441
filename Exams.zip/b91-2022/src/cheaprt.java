public class cheaprt {

    public static int cheapRt(int[]stations,int step1,int step2,int limit){

        return cheapRt(stations,step1,step2,limit,0,"0",0);

    }

    private static int cheapRt(int[]stations,int step1,int step2,int limit,int i,String path,int sum){

        if(i == stations.length-1){
            System.out.println(path +"\t=" +(sum+stations[i]));
            return sum + stations[i];
        }

        if(limit < 0 || i > stations.length-1)
            return Integer.MAX_VALUE;

        int op1 = cheapRt(stations,step1,step2,limit,i+step1,path+"\t"+i,sum+stations[i]);
        int op2 = cheapRt(stations,step1,step2,limit-1,i+step2,path+"\t"+i,sum+stations[i]);

        return Math.min(op1,op2);

    }

    public static void main(String[]args){

        System.out.println(cheapRt(new int[]{2,4,8,3,10,1,12,3,2},3,6,4));
    }
}

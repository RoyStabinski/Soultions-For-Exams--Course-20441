public class findpeak {

    public static int findPeak(int[]arr){

        int first = 0;
        int second = 1;
        int third = 2;

        if(arr[arr.length-1] > arr[arr.length-2])
            return arr[arr.length-1];

        while(third < arr.length){
            if(arr[first] < arr[second] && arr[second] > arr[third])
                return arr[second];
            else
            {
                first++;
                second++;
                third++;
            }
        }

            return -1;//Default
    }

    public static void main(String[]args){
        int[]a = new int[]{5,10,20,15};
        int[]b = new int[]{10,20,15,2,23,90,67};
        int[]c = new int[]{10,20,15,2,90,90,63};
        int[]d = new int[]{1,2,3,4,5};

        System.out.println(findPeak(d));
    }
}

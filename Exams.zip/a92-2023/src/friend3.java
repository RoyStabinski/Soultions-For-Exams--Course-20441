public class friend3 {
    public static int friend3(int[][]mat){

        return friend3(mat,0,1,2,0,"");
    }

    private static int friend3(int[][]mat,int i,int j,int k,int count,String s)
    {
        if(k > mat.length-1){
            j++;
            k = j+1;
        }if(j > mat.length-2){
            i++;
            j = i+1;
            k = j+1;
        }if(i > mat.length-3){
            if(mat[i][j] == 1 && mat[i][k] == 1 && mat[j][k] == 1) {
                return friend3(mat,i,j,k+1,count+1,s+i +"\t"+j+"\t"+k);
            }
        return count;
        }
        return count;

    }

}

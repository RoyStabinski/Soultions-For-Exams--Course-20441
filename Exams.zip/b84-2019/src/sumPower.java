public class sumPower {
    public static boolean sumPower3(int num){

        return sumPower3(num,0);

    }

    private static boolean sumPower3(int num,int power){
        if(num == 0)
            return true;
         if (num < 0)
             return false;

       return sumPower3((int) (num - Math.pow(3,(int)power)),power+1) || sumPower3(num,power+1);


    }

    public static void main(String[]args){
        System.out.println(sumPower3(37));
    }
}

public class avg {
    public static int average(int[] arr) {
        int i = 0;
        int j = 1;
        double max = Integer.MIN_VALUE;
        int index = 0;
        int sum1 = arr[0];
        int sum2 = 0;

        if(arr.length <= 2)
            return 0;

        while (i < arr.length) {
            if (i == arr.length - 1) {
                if ((int) index == index)
                    return index;
                else
                    return index;
            }else if (j < arr.length - 1) {
                sum2 += arr[j];
                j++;
            } else if (j == arr.length - 1) {
                sum2 += arr[j];
                if (Math.abs((double) (sum1 /(i + 1)) - (double) (sum2 / (arr.length - i - 1))) > max) {
                    max = Math.abs((double) (sum1 / (i + 1)) - (double) (sum2 / (arr.length - 1 - i)));
                    index = i;
                }
                i++;
                j = i+1;
                sum1 += arr[i];
                sum2 = 0;
            }
        }
        return index;

    }

    public static void main(String[]args){
        System.out.println(average(new int[]{5,7,-2,10}));
    }

}

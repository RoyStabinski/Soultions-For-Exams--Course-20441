public class howmanypaths {
    public static int howManyPaths(int[][]mat){

        return howManyPaths(mat,0,0,0);

    }

    private static int howManyPaths(int[][]mat,int i,int j,int cnt){
        if(i == mat.length-1 && j == mat[0].length-1)
            return cnt+1;

        if(i < 0 || i > mat.length-1 || j < 0 || j > mat[0].length-1 || mat[i][j] <= 0)
            return Integer.MIN_VALUE;

        int temp = mat[i][j];
        mat[i][j] = -1;

         int op1 = howManyPaths(mat,i + temp,j,cnt);
         int op2 = howManyPaths(mat,i - temp,j,cnt);
         int op3 = howManyPaths(mat,i,j + temp,cnt);
         int op4 = howManyPaths(mat,i,j - temp,cnt);

         mat[i][j] = temp;

         return op1+op2+op3+op4;
        }

        public static void main(String[]args){
        System.out.println(howManyPaths(new int[][]{{1,3,1,6},{2,8,1,2},{6,2,7,5},{2,4,1,3}}));
        }
    }


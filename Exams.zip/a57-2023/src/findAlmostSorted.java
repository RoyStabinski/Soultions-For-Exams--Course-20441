public class findAlmostSorted {
    public static int findAlmostSorted(int[]arr,int num){

        int low = 0;
        int high = arr.length-1;
        int mid;

        while(low <= high) {
            mid = (low + high) / 2;

            if (arr[mid] == num)
                return mid;
            else if (arr[mid] < num)
                if (arr[mid - 1] == num)
                    return mid - 1;
                else high = mid - 2;
            else if (arr[mid + 1] == num)
                return mid + 1;
            else low = mid + 2;
        }

        return -1;


        }

        public static void main(String[]args){

        System.out.println(findAlmostSorted(new int[]{10,3,40,20,50,80,70},40));
        }

    }


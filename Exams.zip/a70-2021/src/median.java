import java.util.Arrays;

public class median {
    public static int getMedian(int[]a,int[]b){
        int n = a.length;
        int[] arr = new int[n+n];
        int i = 0;
        int j = 0;
        int m = 0;

        while(m < arr.length) {
            if (i < n && a[i] <= b[j]) {
                    arr[m] = a[i];
                    m++;
                    i++;

            }else if (j < n) {
                    arr[m] = b[j];
                    m++;
                    j++;
            }
        }
        System.out.println(Arrays.toString(arr));
        if((arr.length % 2)!= 0)
            return arr[(arr.length)/2];
        else
            return ((arr[(arr.length)/2] + arr[((arr.length)/2)-1])/2);


    }

    public static void main(String[]args){
        System.out.println(getMedian(new int[]{1,12,15,26,38},new int[]{12,13,18,30,45}));
    }
}

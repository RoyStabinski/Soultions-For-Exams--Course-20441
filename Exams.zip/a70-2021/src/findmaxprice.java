public class findmaxprice {

    public static int findMaxPrice(int[] prices,int n){

        return findMaxPrice(prices,n,1,0);

    }

    public static int findMaxPrice(int[]prices,int n , int i,int sum){

        if(n == 0)
            return sum;

        if(n < 0 || i >= prices.length-1)
            return Integer.MIN_VALUE;

        int temp = prices[i];
        prices[i] = Integer.MIN_VALUE;
        int op1 = findMaxPrice(prices,n,i+1,sum);
        prices[i] = temp;
        int op2 = findMaxPrice(prices,n-i,i,sum +prices[i]);

        return Math.max(op1,op2);
    }

    public static void main(String[]args){
        System.out.println(findMaxPrice(new int[]{0,1,3,10,9,10,17,17,20},8));
    }
}

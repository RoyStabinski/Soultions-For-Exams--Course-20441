import java.util.Arrays;

public class cnttruereg {
    public static int cntTrueReg(boolean[][]mat){


        int[][]newMat = new int[mat.length][mat.length];
        newMat = newMat(mat,0,0,newMat);
        System.out.println(Arrays.deepToString(newMat));

        return cntTrueReg(newMat,0,0,0,newMat[0][0]);
    }

    private static int cntTrueReg(int[][]newMat,int i,int j,int cnt,int prev) {

        if (i < 0 || i > newMat.length - 1 || j < 0 || j > newMat.length - 1 || newMat[i][j] == 0)
            return cnt+1;


            int temp = newMat[i][j];
            newMat[i][j] = 0;

            int right = cntTrueReg(newMat, i, j + 1, cnt, temp);
            int left = cntTrueReg(newMat, i, j - 1, cnt, temp);
            int up = cntTrueReg(newMat, i - 1, j, cnt, temp);
            int down = cntTrueReg(newMat, i + 1, j, cnt, temp);



            return (left + right + up + down);

        }



        private static int[][] newMat ( boolean[][] mat, int i, int j, int[][] newMat){
            if (i == mat.length - 1 && j == mat.length - 1) {
                if (!mat[i][j])
                    newMat[i][j] = 0;
                else
                    newMat[i][j] = 1;
                return newMat;
            } else if (i < mat.length) {
                if (i == mat.length - 1) {
                    if (!mat[i][j])
                        newMat[i][j] = 0;
                    else
                        newMat[i][j] = 1;
                    return newMat(mat, 0, j + 1, newMat);
                } else {
                    if (!mat[i][j])
                        newMat[i][j] = 0;
                    else
                        newMat[i][j] = 1;
                    return newMat(mat, i + 1, j, newMat);
                }
            }


            return newMat;
        }


    public static void main(String[]args){
        System.out.println(cntTrueReg(new boolean[][]{{false,false,false,false,true},{false,true,true,true,false},{false,false,true,true,false},{true,false,false,false,false},{true,true,false,false,false}}));
    }
}

public class findSmallestsubarray {
    public static int findSmallestSubarrayLen(int[]arr,int num){

        int i = 0;
        int ismall = 0;
        int minLen = Integer.MAX_VALUE;
        int j = 1;
        int sum = 0;
        int cnt = 0;

        while(i < arr.length){
            sum+= arr[i];

            if(sum > num){
                if(cnt < minLen) {
                    minLen = i - cnt;
                    ismall = i;
                }
                System.out.println("Subarray found ["+(i-cnt)+"-"+i+"]");
                i = j;
                j++;
                sum = 0;
                cnt = 0;
            }else{
                i++;
                cnt++;
            }
        }

        if(minLen == Integer.MAX_VALUE)
            System.out.println("No Such array found");
        else
            System.out.println("Smallest Subarray Found ["+(ismall-minLen)+"-"+(ismall+1)+"]");

        return minLen+2;
    }

    public static void main(String[]ags){
        System.out.println(findSmallestSubarrayLen(new int[]{2,6,1,9,7,3,1,4,1,8},15));
    }
}

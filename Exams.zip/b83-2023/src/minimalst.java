public class minimalst
{
    public static String minimalSt(String s1,String s2){

        return minimalSt(s1,s2,"");

    }

    private static String minimalSt(String s1,String s2,String s3) {
        if (s1.length() == 0 && s2.length() == 0)
            return s3;

        if (s1.charAt(0) == s2.charAt(0)) {
            return minimalSt(s1.substring(1), s2.substring(1), s3 + s1.charAt(0));

        } else {
            if (s1.indexOf(s2.charAt(0)) > s2.indexOf(s2.charAt(0)))
                return minimalSt(s1.substring(1), s2, s3 + s1.charAt(0));
            else
                return minimalSt(s1, s2.substring(1), s3 + s2.charAt(0));
        }
    }

    public static void main(String[]args){
        String s1 = "A";
        String s2 = "AA";
        String s3 = "A";
        String s4 = "B";
        String s5 = "AGGTAB";
        String s6 = "GXTXAYB";
        System.out.println(minimalSt(s5,s6));


    }
}

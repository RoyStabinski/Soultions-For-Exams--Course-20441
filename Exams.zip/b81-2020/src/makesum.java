public class makesum {
    public static int makeSum(int[] lengths,int k,int num){

        return makeSum(lengths,0,k,num,0);

    }

    private static int makeSum(int[]lengths,int i , int k ,int num,int cnt){
        if(k == 0 && num >= 0)
            return cnt+1;

        if(k < 0 || i < 0 || i > lengths.length-2 || num < 0)
            return Integer.MIN_VALUE;

        int op1 = makeSum(lengths,i,k - lengths[i],num-1,cnt);
        int op2 = makeSum(lengths,i+1,k,num,cnt);

        return (op1+op2);
    }

    public static void main(String[]args){
        System.out.println(makeSum(new int[]{2,5,10,20,50}, 40, 4));
    }
}

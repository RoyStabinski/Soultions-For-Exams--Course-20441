public class minimumSubK {

    public static void minimumSubK(int[]arr,int k){
        int sum = 0 ;
        int min = Integer.MAX_VALUE;
        int end = 0;
        int step = k;
        for(int i = 0 ; i < arr.length ; i++){
            sum = 0;
            k = step;
            for(int j = i ; j < arr.length && k > 0 ; j++,k--){
                sum += arr[j];
                if(min > sum && k-1 == 0)
                {
                   min = sum;
                   end = j;

                }
            }

        }

        System.out.println("Minimum sum sub-array ("+(end-k) + "," +end+")"+"\t"+min) ;
    }

    public static void main(String[]args){
        minimumSubK(new int[]{10, 4, 2, 5, 6, 3, 8, 1, 5, 9}, 2);
    }
}

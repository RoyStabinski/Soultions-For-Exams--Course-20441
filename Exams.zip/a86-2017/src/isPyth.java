public class isPyth {
    public static boolean isPyth(int[]arr){
        int first = 0;
        int second = 1;
        int third = arr.length-1;

        while(first < second){
            while(second < third){
                if(Math.pow(arr[first],2) + Math.pow(arr[second],2) == Math.pow(arr[third],2))
                    return true;
                else if(Math.pow(arr[first],2) + Math.pow(arr[second],2) < Math.pow(arr[third],2))
                    third--;
                else
                    second++;
            }
            first++;
            second = first+1;
            third = arr.length-1;
        }

        return false;
    }

    public static void main(String[]args){
        int[]a = new int[]{1,3,4,5,6};
        int[]b = new int[]{4,5,6,10,12};

        System.out.println(isPyth(b));
    }
}

public class Covers {

    public static boolean covers(int[][] mat, int[] arr, int k) {

        return covers(mat, 0, 0, arr, 0, k);
    }

    private static boolean covers(int[][] mat, int i, int j, int[] arr, int iarr, int k) {

        if (iarr >= arr.length && k >= 0)
            return true;
        if ( k < 0 || j > mat[0].length - 1 || i > mat.length - 1 || iarr < 0)
            return false;

        if (mat[i][j] == arr[iarr])
        {
            arr[iarr] = 0;
            mat[i][j] = 0;
        }
        boolean op1, op2, op3, op4;
        //if(mat[i][j] == arr[iarr]){
        op1 = covers(mat, i, j, arr, iarr + 1, k);
        op2 = covers(mat, i, j + 1, arr, iarr, k);
        op3 = covers(mat, i + 1, 0, arr, iarr, k - 1);
        op4 = covers(mat, i + 1, 0, arr, 0, k);

        return op1 || op2 || op3 || op4;
    }

    public static void main(String[]args){
        int[][]mat = new int[][]{{1,5,7},{3,2,9},{1,2,3}};
        int[]arr = new int[]{7,2,3};
        System.out.println(covers(mat,arr,1));
    }
}

public class longestslope {
    public static int longestSlope(int[][]mat,int num){

        return longestSlope(mat,0,0,num,0,true);
    }

    private static int longestSlope(int[][]mat,int i,int j,int num,int cnt,boolean flag){
        int op1,op2,op3,op4;

        if(i == mat.length-1 && j == mat[0].length-1)
            return cnt;

        if(i < 0 || i > mat.length-1 || j < 0 || j > mat[0].length-1 || mat[i][j] == Integer.MIN_VALUE || !flag)
            return Integer.MIN_VALUE;
        int temp = mat[i][j];
        mat[i][j] = Integer.MIN_VALUE;
        op1 = longestSlope(mat,i+1,j,num,cnt + 1,isValid(mat,i+1,j) &&temp - mat[i+1][j] == num);
        op2 = longestSlope(mat,i-1,j,num,cnt + 1,isValid(mat,i-1,j) && temp - mat[i-1][j] == num);
        op3 = longestSlope(mat,i,j+1,num,cnt + 1,isValid(mat,i,j+1) && temp - mat[i][j+1] == num);
        op4 = longestSlope(mat,i,j-1,num,cnt + 1,isValid(mat,i,j-1) && temp - mat[i][j-1] == num);
        mat[i][j] = temp;

        return Math.max(Math.max(op1,op2),Math.max(op3,op4));
    }

    private static boolean isValid(int [][]mat,int i,int j){
        return i >= 0 && i <= mat.length - 1 && j >= 0 && j <= mat[0].length - 1;
    }

    public static void main(String[]args){
        int [][]a = new int[][]{{3,13,15,28,30},{55,54,53,27,26},{54,12,52,51,50},{50,10,8,53,11}};
        System.out.println(longestSlope(a,2));
    }
}

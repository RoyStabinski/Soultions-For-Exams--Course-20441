import java.util.Arrays;

public class findword {
    public static void findWord(char[][]arr,String word){
       int[][]mat = new int[arr.length][arr.length];
        if(!findWord(arr,mat,word,"",0,0,0))
            System.out.println("No Such Word");
        else
            System.out.println(findWord(arr,mat,word,"",0,0,0));
    }

    private static boolean findWord(char[][]arr,int[][]mat,String word,String word1,int wordI,int i ,int j) {
        char temp;

        if (word1.length() == word.length()){
            System.out.println(Arrays.deepToString(mat));
        return true;
    }
        if(i < 0 || i > arr.length-1 || j < 0 || j > arr.length-1 || arr[i][j] == 'A') {
            return false;
        }
        temp = arr[i][j];
        arr[i][j] ='A';
        if(temp == word.charAt(wordI)) {
            mat[i][j] = wordI+1;
            boolean left = findWord(arr, mat,word, word1 + word.charAt(wordI), wordI + 1, i, j - 1);
            boolean right = findWord(arr, mat,word, word1 + word.charAt(wordI), wordI + 1, i, j + 1);
            boolean up = findWord(arr, mat,word, word1 + word.charAt(wordI), wordI + 1, i - 1, j);
            boolean down = findWord(arr, mat,word, word1 + word.charAt(wordI), wordI + 1, i + 1, j);
            arr[i][j] = temp;
            return left || right || down ||up;

        }else{
            mat[i][j] = 0 ;
            boolean resetL = findWord(arr,mat,word,"",0,i,j-1);
            boolean resetR = findWord(arr,mat,word,"",0,i,j+1);
            boolean resetU = findWord(arr,mat,word,"",0,i+1,j);
            boolean resetD = findWord(arr,mat,word,"",0,i-1,j);
            arr[i][j] = temp;
            return resetL || resetR || resetU || resetD;
        }
    }


    public static void main(String[]args){
        findWord(new char[][]{{'t','z','x','c','d'},{'s','h','a','z','x'},{'h','w','l','o','m'},{'o','r','n','t','n'},{'a','b','r','i','n'}},"shalomk");
    }
}

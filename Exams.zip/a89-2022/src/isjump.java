public class isjump {

    public static boolean isJump(String str1,String str2,int step){
        if(str2.length() > str1.length())
            return false;

        if(str1.charAt(0) != str2.charAt(0))
            return false;

        return isJump(str1,str2,step,1);

    }

    private static boolean isJump(String str1,String str2,int step,int i){

        if(i > str2.length()-1 || step > str1.length())
            return true;

        if(str1.charAt(step) == str2.charAt(i))
            return isJump(str1,str2,step*2,i+1);
        else
            return false;
    }

    public static void main(String[]args){
        System.out.println(strstep("abcfbaagcxabcd","abc"));
    }

    public static int strstep(String str1,String str2){

        int jump = str1.indexOf(str2.charAt(1));

        if(str2.length() > str1.length())
            return -1;
        if(str2.charAt(0) != str1.charAt(0))
            return -1;

        if(!(isJump(str1, str2, jump)))
            return -1;

        return Math.min(jump,Integer.MAX_VALUE);

    }

}

public class longestsubarray {

    public static int longestSubarray(int[]a){

        int i = 0;
        int j = 1;
        int p = 0;
        int start = 0;
        int max = 1;


        while(j < a.length){
            if(a[p] * a[j] < 0) {
                p = j;
                j++;
                if(j-i > max){
                    max = j - i;
                    start = i;
                }
            }else {
                i++;
                p = i;
                j = p+1;
            }

        }

        System.out.println("Starting Index = " +start + " Ending Index = " + (start+max-1));
        return max;

    }

    public static void main(String[]args){
        System.out.println(longestSubarray(new int[]{}));
    }
}

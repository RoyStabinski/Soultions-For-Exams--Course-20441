public class Triples {

    public static int countTriples(int[]arr,int num){

        int first = 0;
        int second = 1;
        int third = arr.length-1;
        int cnt = 0;

        while(first < second && second < third){
            while(second < third) {
                if (arr[first] + arr[second] + arr[third] < num) {
                    cnt++;
                }
                if(third -1 == second ){
                    third = arr.length - 1;
                    second++;
                }else
                    third--;
            }
            first++;
            second = first+1;
            third = arr.length-1;
        }

            return cnt;
    }

    public static void main(String[]args){
        System.out.println(countTriples(new int[]{-2,0,1,3},2));
    }

}

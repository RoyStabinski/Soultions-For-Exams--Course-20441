public class Edit {
    public static int edit(String str1,String str2){

        return edit(str1,str2,0);

    }

    private static int edit(String str1,String str2,int cnt){

        if(str1.length() == 0 && str2.length() == 0)
            return cnt;

        if(str1.length() == 0)
            return cnt + str2.length();

        if(str2.length() == 0)
            return cnt + str1.length();

        if(str1.charAt(0) == str2.charAt(0))
            return edit(str1.substring(1),str2.substring(1),cnt);

        return Math.min(edit(str1.substring(1),str2,cnt+1),edit(str1,str2.substring(1),cnt+1));
    }

    public static void main(String[]args){
        String str1 = "geek";
        String str2 = "gesek";
        String str3 = "sunday";
        String str4 = "saturday";

        System.out.println(edit(str1,str2));
    }
}

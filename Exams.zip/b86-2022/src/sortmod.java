import java.util.Arrays;

public class sortmod {
        public static int[] sortMod(int[] a, int k){

            int newIndex = 0;
            int temp;
            for(int i = 0 ; i < k;i++){//Module
                for(int j = 0 ; j < a.length;j++){//sorting from low to high
                    if (a[j] % k == i) {
                        temp = a[newIndex];
                        a[newIndex] = a[j];
                        a[j] = temp;
                        newIndex++;
                    }
                }
            }
            return a;

        }

        public static void main(String[]args){

           System.out.print(Arrays.toString(sortMod(new int[]{35, 17, 13, 252, 4, 128, 7, 3, 81}, 10)));
        }

    }


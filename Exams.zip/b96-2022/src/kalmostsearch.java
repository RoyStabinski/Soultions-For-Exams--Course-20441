public class kalmostsearch {

    public static int kAlmostSearch(int[]a,int num) {

        int low = 0;
        int high = a.length-1;
        int mid;


        while( low <= high){
            mid = (low+high)/2;
            if(a[mid] == num)
                return mid;
            else if(a[mid] == 0){
                int i;
                for( i = mid; i >= low ; i--){
                    if(a[i] == num)
                        return i;
                    if(a[i] == 0)
                        continue;
                    else if(a[i] > num) {
                        high = i - 1;
                        i = -1;
                        break;
                    }else if(a[i] < num) {
                        low = i + 1;
                        i = -1;
                        break;
                    }
                }

                if(low+1 == high)
                    if(a[low] == num)
                        return low;
                else if(a[high] == num)
                    return high;
                else
                    return -1;

                if(i != -1)
                for( i = mid; i <= high;i++) {
                    if (a[i] == num)
                        return i;
                    if (a[i] == 0)
                        continue;
                    else if (a[i] > num) {
                        high = i - 1;
                        break;
                    } else {
                        low = i + 1;
                        break;
                    }
                }
                }else if(a[mid] > num)
                    high = mid-1;
                else
                low = mid + 1;

        }
        return -1;
    }

    public static void main(String[]args){
        System.out.println(kAlmostSearch(new int[]{3,0,0,4,7,9,0,0,0,0,11,15,0,19,20,0,0,31,40,0},9));
    }
}

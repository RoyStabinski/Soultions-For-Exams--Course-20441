public class calc {

    public static int Calc(int num,int result,int maxOp){

        if(num == 0 && result == 0)
            return 0;

        return Calc(num,result,maxOp,""+num,num,0);
    }


    private static int Calc(int num , int result,int maxOp,String s,int temp,int cnt){

        if(temp == result && maxOp  >=0){
            System.out.println(s + " = " +result);
            return cnt+1;
        }

        if(maxOp < 0)
            return Integer.MIN_VALUE;

        int op1 = Calc(num,result , maxOp -1,s +" + " +num,temp +num,cnt);
        int op2 = Calc(num,result , maxOp-1 , s+ " - " +num,temp-num,cnt);
        int op3 = Calc(num,result,maxOp-1,s + " * " + num,temp*num,cnt);
        int op4 = Calc(num,result,maxOp-1, s + " / " +num,temp/num,cnt);


        return op1+op2+op3+op4;
    }

    public static void main(String[]args){

        System.out.println(Calc(3,36,4));
    }


}

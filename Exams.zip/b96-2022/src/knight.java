import java.util.Arrays;

public class knight {
    public static int maxSumKnight(int[][]mat) {

        return maxSumKnight(mat,0,0,0,"");
    }

    private static int maxSumKnight(int[][] mat, int i, int j, int max,String s) {

        if (i == mat.length - 1 && j == mat[0].length - 1) {
            System.out.println(s);
            return max + mat[i][j];
        }

        if (i < 0 || i >= mat.length || j < 0 || j >= mat[0].length || mat[i][j] == -1)
            return -1;

        int temp = mat[i][j];
        mat[i][j] = -1;

        int op1 = maxSumKnight(mat, i - 1, j - 2, max +(isValid(mat,i-1,j-2) && Math.abs(temp-mat[i][j])<=1?temp:Integer.MIN_VALUE),s+i+j+",");
        int op2 = maxSumKnight(mat, i - 2, j - 1, max +(isValid(mat,i-2,j-1)&&Math.abs(temp-mat[i][j])<=1?temp:Integer.MIN_VALUE),s+i+j+",");
        int op3 = maxSumKnight(mat, i - 2, j + 1, max +(isValid(mat,i-2,j+1)&&Math.abs(temp-mat[i][j])<=1?temp:Integer.MIN_VALUE),s+i+j+",");
        int op4 = maxSumKnight(mat, i - 1, j + 2, max +(isValid(mat,i-1,j+2)&&Math.abs(temp - mat[i][j])<=1?temp:Integer.MIN_VALUE),s+i+j+",");
        int op5 = maxSumKnight(mat, i + 1, j - 2, max +(isValid(mat,i+1,j-2)&&Math.abs(temp-mat[i][j])<=1?temp:Integer.MIN_VALUE),s+i+j+",");
        int op6 = maxSumKnight(mat, i + 2, j - 1, max + (isValid(mat,i+2,j-1)&&Math.abs(temp- mat[i][j]) <= 1 ? temp : Integer.MIN_VALUE),s+i+j+",");
        int op7 = maxSumKnight(mat, i + 2, j + 1, max + (isValid(mat,i+2,j+1)&&Math.abs(temp - mat[i][j]) <= 1 ? temp : Integer.MIN_VALUE),s+i+j+",");
        int op8 = maxSumKnight(mat, i + 1, j + 2, max + (isValid(mat,i+1,j+2)&&Math.abs(temp - mat[i][j]) <= 1 ? temp : Integer.MIN_VALUE),s+i+j+",");

        mat[i][j] = temp;

        return Math.max(Math.max(Math.max(op1,op2),Math.max(op3,op4)), Math.max(Math.max(op5,op6),Math.max(op7,op8)));
    }

    private static boolean isValid(int[][]mat,int i,int j){
        return (i >= 0 && i < mat.length && j >= 0 && j < mat[0].length);
    }

    public static void main(String[]args){
        System.out.println(maxSumKnight(new int[][]{{4,5,6,7,1},{3,5,1,7,4},{4,5,6,5,8},{3,4,7,7,9},{6,2,2,7,6}}));
    }
}

public class onefiveseven {
    public static int oneFiveSeven(int n){

return oneFiveSeven(n,0);    }

    private static int oneFiveSeven(int n,int cnt){
        if(n == 0)
            return cnt;
        if(n < 0 )
            return Integer.MAX_VALUE;

        int op1 = oneFiveSeven(n-1,cnt+1);
        int op5 = oneFiveSeven(n-5,cnt+1);
        int op7 = oneFiveSeven(n-7,cnt+1);

        if(op1 <= op5 && op1 <= op7)
            return op1;
        else if(op5 <= op1 && op5 <= op7)
            return op5;
        else if(op7 <= op5 && op7 <= op1)
            return op7;

        return Integer.MAX_VALUE;

    }

    public static void main(String[]args){
        System.out.println(oneFiveSeven(14));
    }
}

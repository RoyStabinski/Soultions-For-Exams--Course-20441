public class printclosest {
    public static void printclosest(int[] a, int[] b, int x) {
        int ia  = 0;
        int ib = b.length-1;
        int closea = 0;
        int closeb = b.length-1;
        int preva = -1;
        int prevb = -1;

        while(preva != ia && prevb != ib){

            if(Math.abs(a[ia] + b[ib] - x) <= Math.abs(a[closea] + b[closeb] - x))
            {
                closea = ia;
                closeb = ib;
            }

            if(a[ia] + b[ib] == x) {
                break;
            }
            else if(a[ia] + b[ib] > x)
            {
                prevb = ib;
                if(ib == 0)
                    ib = ib;
                else
                    ib--;
            }else{
                    preva = ia;
                    if(ia == a.length-1)
                       ia = ia;
                    else
                        ia++;
            }

        }

        System.out.println(a[closea] + " and " + b[closeb]);
    }

    public static void main(String[]args){
        int[]a = new int[]{0,4,6,11,11};
        int[]b = new int[]{10,20,30,40};

        printclosest(a, b, 26);

    }
}

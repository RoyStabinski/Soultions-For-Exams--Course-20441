public class cheapestroute {

    public static int cheapesstRoute(int[] stations){

        return cheapestRoute(stations,0,0);
    }

    private static int cheapestRoute(int[]stations,int i,int sum){

        if( i == stations.length-1)
            return sum +stations[i];

        if(i > stations.length-1)
            return Integer.MAX_VALUE;

        return Math.min(cheapestRoute(stations,i+1,sum+stations[i]),cheapestRoute(stations,i+2,sum+stations[i]));
    }

    public static void main(String[]args){
        System.out.println(cheapesstRoute(new int[]{2,8,3,4,7,1,3,2}));
    }
}

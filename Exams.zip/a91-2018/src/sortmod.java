import java.util.Arrays;

public class sortmod {
    public static void sortMod(int[]a,int k){

        int i;
        int temp;
        int pivot = 0;

        for(int mod = 1 ; mod <= k ;mod++) {
            for (i = mod - 1; i < a.length; i++) {
                if (a[i] % k == mod) {
                    temp = a[pivot];
                    a[pivot] = a[i];
                    a[i] = temp;
                    pivot += 1;
                }
            }
        }

        System.out.println(Arrays.toString(a));
    }

    public static void main(String[]args){
        sortMod(new int[]{35,17,13,252,4,128,7,3,81},10);
    }
}

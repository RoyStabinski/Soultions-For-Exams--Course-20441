

public class countpairs {

    public static int countPairs(int n){

        return countPairs(n,0,0,0,"");
    }

    private static int countPairs(int n,int cnt,int open,int close,String s){

        if(s.length() == n*2 && open == close)
        {
            System.out.println(s);
            return cnt+1;
        }

        if(open == close)
            return countPairs(n,cnt,open+1,close,s +"(");

        if(open == n)
            return countPairs(n,cnt,open,close +1,s +")");

        return countPairs(n,cnt,open+1,close,s +"(") + countPairs(n,cnt,open,close+1,s+")");

    }

    public static void main(String[]args){
        System.out.println(countPairs(3));
    }



}

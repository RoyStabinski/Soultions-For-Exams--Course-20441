public class superinc {
    public static boolean superInc(int[]arr,int k){

        int sum = k;
        for(int i = arr.length-1 ; i >= 0;i--){
            if(arr[i] == sum)
                return true;
            if(arr[i] < sum)
                sum-=arr[i];
        }

        return false;
    }

    public static void main(String[]args){

        System.out.println(superInc(new int[]{2,3,8,27},30));
    }
}

public class howmanyneg {
    public static int howManyNegativeNumbers(int[][]arr){
        int j = 0;
        int i = 0;
        int cnt = 0;

        if(arr[0][0] >= 0)
            return 0;

        while(j < arr[0].length){
            if(j == arr[0].length-1 && arr[i][j] >= 0)
                return cnt;
            else if(arr[i][j] >= 0) {
                j++;
                i = 0;
            }else if(arr[i][j] < 0){
                cnt+=1;
                if(i == arr.length-1) {
                    i = 0;
                    j++;
                }else{
                    i++;
                }
            }
        }
        return 0;
    }

    public static void main(String[]args){
        System.out.println(howManyNegativeNumbers(new int[][]{{-99,-72,-64,-55,-28,-10,-5},{-72,-53,-46,-38,11,13,22},{-63,-48,-27,-12,14,16,23},{-44,-29,-10,0,18,20,28},{0,12,14,20,28,30,35}}));
    }
}

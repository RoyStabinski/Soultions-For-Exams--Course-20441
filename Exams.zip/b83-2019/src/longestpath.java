import java.util.Arrays;

public class longestpath {
    public static int longestPath(int[][] mat,int x,int y){
        return longestPath(mat,0,0,0,x,y);
    }

    private static int longestPath(int[][]mat,int i,int j,int max,int x,int y){
        if(i == x && j == y) {
            System.out.println(Arrays.deepToString(mat));
            return max + 1;
        }

        if(i < 0 || i > mat.length-1 || j < 0 || j > mat[0].length-1 || mat[i][j] < 1)
            return -1;

        int temp = mat[i][j];
        mat[i][j] = -1;

        int op1 = longestPath(mat,i+1,j,max+1,x,y);
        int op2 = longestPath(mat,i-1,j,max+1,x,y);
        int op3 = longestPath(mat,i,j-1,max+1,x,y);
        int op4 = longestPath(mat,i,j+1,max+1,x,y);

        mat[i][j] = temp;

        return Math.max(Math.max(op1,op2),Math.max(op3,op4));
    }

    public static void main(String[]args){
        System.out.println(longestPath(new int[][]{{1,1,1,1,1,1,1},{1,1,0,1,0,0,1},{1,1,1,1,0,1,1}},2,5));
    }
}

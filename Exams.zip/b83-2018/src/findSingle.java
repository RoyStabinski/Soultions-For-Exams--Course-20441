public class findSingle {

    public static int findSingle(int[]a){

        int first = 0;
        int second = 1;

        while(second < a.length){
            if(a[first] == a[second]){
                if(second == a.length-2)
                return a.length-1;
                else {
                    first += 2;
                    second += 2;
                }
                }else if(a[first] != a[second] && a[second+1] == a[second])
                    return first;
        }

        return first;
    }

    public static void main(String[]args){
        int[]a= new int[]{6,6,18,18,-4,-4,12,9,9};
        int[]b = new int[]{8,8,-7,-7,3,3,0,0,10,10,5,5,4};
        int[]c = new int []{0};

        System.out.println(findSingle(c));
    }
}

public class Prince {
    public static int prince(int[][]drm,int i,int j){

        return prince(drm,i,j,0,drm[i][j]);

    }

    private static int prince(int[][]drm ,int i,int j,int cnt,int prev){

        if(i < 0 || i >= drm.length || j < 0 || j >= drm[0].length || drm[i][j] == -2)
            return Integer.MAX_VALUE;

        if(drm[i][j] == -1)
            return cnt+1;

        if(!move(drm,prev,drm[i][j]))
            return Integer.MAX_VALUE;

        int temp = drm[i][j];
        drm[i][j] = -2;

        int left = prince(drm,i,j-1,cnt + 1,temp);
        int right = prince(drm,i,j+1,cnt + 1,temp);
        int up = prince(drm,i-1,j,cnt + 1,temp);
        int down = prince(drm,i+1,j,cnt + 1,temp);

        drm[i][j] = temp;

        return Math.min(Math.min(left,right),Math.min(up,down));
    }

    private static boolean move(int[][]drm,int temp,int prev){
        if((Math.abs(temp - prev) <= 1 || temp - prev == 2 || temp == -1))
            return true;
        else
            return false;
    }

    public static void main(String[]args){
        int[][]a = new int[][]{{2,0,1,2,3},{2,3,5,5,4},{8,-1,6,8,7},{3,4,7,2,4},{2,4,3,1,2}};
        System.out.println(prince(a,0,0));
    }
}

import java.util.Arrays;

public class greatestroute {
    public static int greatestRoute(int[][]mat){

        int newMat[][] = new int[mat.length][mat[0].length];
        copy(mat,0,0,newMat);
        if(mat[0][0] == 0)
        {
            System.out.println("No Such a route");
            return 0;
        }

        return greatestRoute(mat,0,0,mat[0][0],"");
    }

    private static int greatestRoute(int[][]mat,int i,int j,int sum,String s){

        if(i == mat.length-1 && j == mat[0].length-1)
        {
            System.out.println(s + " ("+i+","+j+")" +" = "+(sum+1));
            return (sum+1);
        }

        if(i < 0 || i > mat.length-1 || j < 0 || j > mat[0].length-1 || mat[i][j] <= 0)
            return Integer.MIN_VALUE;

        int temp = mat[i][j];
        mat[i][j] = temp-1;
        int left = greatestRoute(mat,i,j-1,sum+temp , s +" ("+i +"," +j+")"+" --->");
        int right = greatestRoute(mat,i,j+1,sum+temp,s +" ("+i +"," +j+")"+" --->");
        int up = greatestRoute(mat,i-1,j,sum+temp,s +" ("+i +"," +j+")"+" --->");
        int down = greatestRoute(mat,i+1,j,sum+temp,s +" ("+i +"," +j+")"+" --->");
        mat[i][j] = temp;


        return Math.max(Math.max(left,right),Math.max(up,down));
    }

    private static int[][]copy(int[][]mat,int i,int j,int[][]newMat){
        if(i == mat.length-1 && j == mat[0].length-1) {
            newMat[i][j] = mat[i][j];
            return newMat;
        }
        else if(i < mat.length-1) {
            newMat[i][j] = mat[i][j];
            copy(mat, i + 1, j, newMat);
        }else if( i == mat.length-1) {
            newMat[i][j] = mat[i][j];
            copy(mat, 0, j + 1, newMat);
        }
        System.out.println(Arrays.deepToString(newMat));
        return newMat;


    }

    public static void main(String[]args){
        System.out.println(greatestRoute(new int[][]{{2,3},{4,1}}));
    }
}

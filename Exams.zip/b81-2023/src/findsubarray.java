public class findsubarray {

    public static void findSubArray(int[]arr,int target){

        int i = 0;
        int j = 1;
        int cnt = 0;
        int sum = 0;

        while(i < arr.length){
            sum += arr[i];
            if(sum == target)
                System.out.println("Subarray found between indexs " +(i-cnt) +" and " +i);
            else if(sum < target) {
                i++;
                cnt++;
            }else{
                i = j;
                j++;
                cnt = 0;
                sum = 0;
            }
        }

        if(j > arr.length-1)
            System.out.println("No Such a Subarray");
    }

    public static void main(String[]args){

        int[]a= new int[]{2,6,0,1,9,7,3,1,4,1,8};
        findSubArray(a, 15);

    }
}

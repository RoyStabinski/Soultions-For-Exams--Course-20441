public class findsmallest {
    public static int findSmallest(int[] arr) {

        int j;
        int sum = arr[0];

        if (arr[0] > 1)
            return 1;

        for(j = 1 ; j < arr.length;j++) {
            if(arr[j] - sum > 1)
                return sum+1;
            else
            {
                sum += arr[j];
            }

    }
        return sum+1;
    }

    public static void main(String[]args){
        int[]a = new int[]{1,1,1,1};
        int[]b = new int[]{1,1,3,4};
        int[]c = new int[]{1,3,5,10,20,40};
        int[]d = new int[]{1,2,4,10,11,15};

        System.out.println(findSmallest(d));
    }
}
